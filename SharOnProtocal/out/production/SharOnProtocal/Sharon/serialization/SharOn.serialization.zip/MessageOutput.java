/************************************************
 *
 * Author: Chris Simmons, Mitchell Shannon
 * Assignment: Program0Test
 * Class: CSI 4321 Data Communications
 *
 ************************************************/

package Sharon.serialization;

/**
 * Serialization output for messages
 */
public class MessageOutput {
    /**
     * Constructs a new output source from an OutputStream
     *
     * @param out is the byte output sink
     */
    public MessageOutput(java.io.OutputStream out)
    {

    }
}
