/************************************************
 *
 * Author: Chris Simmons, Mitchell Shannon
 * Assignment: Program0Test
 * Class: CSI 4321 Data Communications
 *
 ************************************************/

package Sharon.serialization;

/**
 * Represents a SharOn search result and provides serialization/deserialization
 */
public class Result {

    private long fileID; //unique Id for file
    private long fileSize; //size of file
    private String fileName; //name of the file

    /**
     * Result constructor that sets all fields by reading the MessageInput
     *
     * @param in is the MessageInput that is read to set fields
     * @throws BadAttributeValueException
     *     if in is empty, does not follow format, or is too large
     */
    public Result(MessageInput in)
            throws BadAttributeValueException
    {

    }


    /**
     * Result constructor that sets all fields to respective parameters
     *
     * @param fileID is the long that is the new fileId
     * @param fileSize is the long that is the new fileSize
     * @param fileName is the String that is the new fileName
     *
     * @throws BadAttributeValueException
     *     if any long parameter is negative, or String parameter is null
     */
    public Result(long fileID, long fileSize, String fileName)
            throws BadAttributeValueException
    {
        this.fileID = fileID;
        this.fileSize = fileSize;
        this.fileName = fileName;
    }

    /**
     * Serialize Result to given output stream
     *
     * @param out is the output stream to serialize to
     *
     * @throws java.io.IOException
     *     if out is unable to be serialized
     */
    public void encode(MessageOutput out)
            throws  java.io.IOException
    {

    }

    /**
     * Returns human-readable Result object
     *
     * @return String of human-readable Result object
     */
    public java.lang.String toString()
    {
        return null;
    }

    /**
     * Get fileId
     *
     * @return long of fileId
     */
    public long getFileID()
    {
        return fileID;
    }

    /**
     * set fileId
     *
     * @param fileID is the long that is the new fileId
     *
     * @throws BadAttributeValueException
     *     if the long is negative
     */
    public void setFileID(long fileID)
            throws BadAttributeValueException
    {
        this.fileID = fileID;
    }

    /**
     * get fileSize
     *
     * @return long of fileSize
     */
    public long getFileSize()
    {
        return fileSize;
    }

    /**
     * set fileSize
     *
     * @param fileSize is the long that is the new fileSize
     *
     * @throws BadAttributeValueException
     *     if the long is less than zero
     */
    public void setFileSize(long fileSize)
            throws BadAttributeValueException
    {
        this.fileSize = fileSize;
    }

    /**
     * get fileName
     *
     * @return String of fileName
     */
    public String getFileName()
    {
        return fileName;
    }

    public void setFileName(java.lang.String fileName)
            throws BadAttributeValueException
    {
        this.fileName = fileName;
    }

    /**
     * returns hashcode value for Result
     *
     * Contract:
     *     - Hashcode must remain consistent through multiple calls on same obj
     *     - Two objects that are equal will have the same hashcode
     *     - Two unequal objs may have the same hashcode
     *
     * @return int hashcode of Result object
     */
    public int hashCode()
    {
        return 0;
    }

    /**
     * indicates if some other object is "equal" to this Result
     *
     * @param obj is the object that is compared to this Result
     *
     * @return boolean from comparison of object and this Result
     */
    public boolean equals(Object obj)
    {
        return false;
    }


}
