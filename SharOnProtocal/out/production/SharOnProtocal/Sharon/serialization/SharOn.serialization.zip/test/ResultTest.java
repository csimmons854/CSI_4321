/************************************************
 *
 * Author: Chris Simmons, Mitchell Shannon
 * Assignment: Program0Test
 * Class: CSI 4321 Data Communications
 *
 ************************************************/

import Sharon.serialization.BadAttributeValueException;
import Sharon.serialization.MessageInput;
import Sharon.serialization.Result;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *  JUnit test suite for the result class
 */
public class ResultTest
{
    private Result rslt;
    private MessageInput in;

    @Test
    public void resultMessageConstructorSuccessTest() throws Exception
    {
        rslt = new Result(in);
    }

    @Test (expected = BadAttributeValueException.class)
    public void resultMessageConstructorExceptionTest() throws Exception
    {
        rslt = new Result(null);
    }

    @Test
    public void resultConstructorParametersSuccessTest() throws Exception
    {
        rslt = new Result(1,1,"test");
    }

    @Test (expected = BadAttributeValueException.class)
    public void resultConstructorFileIdExceptionTest() throws Exception
    {
        rslt = new Result(-1,1,"test");
    }

    @Test (expected = BadAttributeValueException.class)
    public void resultConstructorFileSizeExceptionTest() throws Exception
    {
        rslt = new Result(1,-1,"test");
    }

    @Test (expected = BadAttributeValueException.class)
    public void resultConstructorFileNameExceptionTest() throws Exception
    {
        rslt = new Result(1,1,null);
    }


	@Test (expected = java.io.IOException.class)
	public void encodeIOExceptionTest() throws Exception {
        rslt = new Result(1,1,"test");
		rslt.encode(null);
	}

	@Test
	public void encodeSuccessTest() throws Exception {
        rslt = new Result(1,1,"test");
        rslt.encode(null);
	}

	@Test
	public void toStringSuccessTest() throws Exception {
        rslt = new Result(892145433,12,"test");
		assertEquals(rslt.toString(),"892145433, 12, test");
	}

	@Test
	public void getFileIDTest() throws Exception {
	    Result testRslt = new Result(10,10,"10");
	    assertEquals(testRslt.getFileID(),10);
	}

	@Test
	public void setFileIDTest() throws Exception {
        rslt = new Result(1,1,"test");
		rslt.setFileID(10);
		assertEquals(10L,rslt.getFileID());
	}

    @Test (expected = BadAttributeValueException.class)
    public void setFileIDExceptionTest() throws Exception {
        rslt = new Result(1,1,"test");
        rslt.setFileID(-1);
    }

	@Test
	public void getFileSizeTest() throws Exception {
        Result testRslt = new Result(10,10,"10");
        assertEquals(testRslt.getFileSize(),10);
	}

	@Test
	public void setFileSizeTest() throws Exception {
	    rslt = new Result(1,1,"test");
		rslt.setFileSize(10);
		assertEquals(10L,rslt.getFileSize());
	}

    @Test (expected = BadAttributeValueException.class)
    public void setFileSizeExceptionTest() throws Exception {
        rslt = new Result(1,1,"test");
        rslt.setFileSize(-1);
    }

	@Test
	public void getFileNameTest() throws Exception {
        Result testRslt = new Result(10,10,"10");
        assertEquals(testRslt.getFileName(),"10");
	}

	@Test
	public void setFileNameTest() throws Exception {
        rslt = new Result(1,1,"test");
		rslt.setFileName("new");
		assertEquals(rslt.getFileName(),"new");
	}

    @Test (expected = BadAttributeValueException.class)
    public void setFileNameExceptionTest() throws Exception {
        rslt = new Result(1,1,"test");
        rslt.setFileName(null);
    }

	@Test
	public void hashCodeConsistencyTest() throws Exception {
        rslt = new Result(1,1,"test");
	    assertEquals(rslt.hashCode(),rslt.hashCode());
	}

    @Test
    public void hashCodeEqualsTest() throws Exception {
	    Result rslt1 = new Result(1,1,"test");
        Result rslt2 = new Result(1,1,"test");
        assertEquals(rslt1.hashCode(),rslt2.hashCode());
    }

	@Test
	public void equalsSuccessTest() throws Exception {
	    Result rslt1 = new Result(1, 1, "test");
        Result rslt2 = new Result(1,1,"test");
        assertTrue(rslt1.equals(rslt2));
	}

    @Test
    public void equalsKnownFalseTest() throws Exception {
        Result rslt1 = new Result(1, 1, "test");
        Result rslt2 = new Result(2,2,"quiz");
        assertFalse(rslt1.equals(rslt2));
    }

    @Test
    public void equalsBothNullTest() throws Exception {
        Result rslt1 = new Result(0, 0, null);
        Result rslt2 = new Result(0,0,null);
        assertTrue(rslt1.equals(rslt2));
    }

    @Test
    public void equalsSingleNullTest() throws Exception {
        Result rslt1 = new Result(1, 1, "test");
        Result rslt2 = new Result(0,0,null);
        assertFalse(rslt1.equals(rslt2));
    }

}