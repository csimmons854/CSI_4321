/************************************************
 *
 * Author: Chris Simmons and Mitchell Shannon
 * Assignment: Program1Test
 * Class: CSI 4321 Data Communications
 *
 ************************************************/
package mvn.serialization.test;

import mvn.serialization.ErrorType;
import mvn.serialization.Packet;
import mvn.serialization.PacketType;
import org.junit.Test;

import java.io.IOException;

import static mvn.serialization.ErrorType.None;
import static mvn.serialization.PacketType.AnswerRequest;
import static org.junit.Assert.*;


public class packetTest {
    /**
     * Test for Packet(Byte [] buffer) constructor success
     */
    @Test
    public void packetByteArrayConstructorSuccessTest() throws IOException,
            IllegalArgumentException {
        byte [] buffer = null;
        PacketType type = AnswerRequest;
        ErrorType error = None;
        //Will build buffer later when I implement constructor

        Packet packet1 = new Packet(buffer);
        Packet packet2 = new Packet(type,error,0);

        assertEquals(packet2,packet1);
    }

    /**
     * Test for Packet(Byte [] buffer) buffer too large Exception
     */
    @Test (expected = IOException.class)
    public void packetByteArrayConstructorBufferToLongTest() throws IOException,
            IllegalArgumentException {
        byte [] buffer = new byte[1563];

        new Packet(buffer);
    }

    /**
     * Test for Packet(Byte [] buffer) buffer too small Exception
     */
    @Test (expected = IOException.class)
    public void packetByteArrayConstructorBufferToShortTest() throws IOException,
            IllegalArgumentException {
        byte [] buffer = new byte[0];

        new Packet(buffer);
    }

    /**
     * Test for Packet(Byte [] buffer) buffer null Exception
     */
    @Test (expected = IOException.class)
    public void packetByteArrayConstructorBufferNullTest() throws IOException,
            IllegalArgumentException {
        byte [] buffer = null;

        new Packet(buffer);
    }

    /**
     * Test for Packet(Byte [] buffer) invalid packet type exception
     */
    @Test (expected = IllegalArgumentException.class)
    public void packetByteArrayConstructorBufferBadTypeTest() throws
            IOException, IllegalArgumentException {
        byte [] buffer = null;
        //Will build buffer later when I implement constructor

        new Packet(buffer);
    }

    /**
     * Test for Packet(Byte [] buffer) invalid error type exception
     */
    @Test (expected = IllegalArgumentException.class)
    public void packetByteArrayConstructorBufferBadErrorTest() throws
            IOException, IllegalArgumentException {
        byte [] buffer = null;
        //Will build buffer later when I implement constructor

        new Packet(buffer);
    }

    /**
     * Test for Packet(PacketType, ErrorType, Int) constructor success
     */
    @Test
    public void packetConstructorSuccessTest() throws
            IOException, IllegalArgumentException {
        Packet packet1 = new Packet(AnswerRequest,None,0);

        assertTrue(packet1.getError() == None &&
                    packet1.getType() == AnswerRequest &&
                    packet1.getSessionID() == 0);
    }

    /**
     * Test for Packet(PacketType, ErrorType, Int) invalid session ID
     * too small
     */
    @Test (expected = IllegalArgumentException.class)
    public void packetConstructorBadPacketTypeTooSmallTest() throws
            IOException, IllegalArgumentException {
        Packet packet1 = new Packet(AnswerRequest,None,-1);

    }


    /**
     * Test for Packet(PacketType, ErrorType, Int) invalid session ID
     * too large
     */
    @Test (expected = IllegalArgumentException.class)
    public void packetConstructorBadPacketTypeTooLargeTest() throws
            IOException, IllegalArgumentException {
        Packet packet1 = new Packet(AnswerRequest,None,256);

    }

    /**
     * Test that Encode returns the same byte [] given to the Packet constructor
     */
    @Test
    public void encodeSuccessTest() throws Exception {
        //Buffer to compare against
        //Will be implemented later
        byte [] buffer = null;
        Packet packet = new Packet(buffer);

        assertArrayEquals(packet.encode(),buffer);
    }

    /**
     * test that getType returns the same PacketType given to the Packet
     */
    @Test
    public void getType() throws Exception {
        PacketType type = AnswerRequest;
        Packet packet = new Packet(AnswerRequest,None,0);
        assertEquals(type,packet.getType());
    }

    @Test
    public void getError() throws Exception {
    }

    @Test
    public void setSessionID() throws Exception {
    }

    @Test
    public void getSessionID() throws Exception {
    }

    @Test
    public void addAddress() throws Exception {
    }

    @Test
    public void getAddrList() throws Exception {
    }

}