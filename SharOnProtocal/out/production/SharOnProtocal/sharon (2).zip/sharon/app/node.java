package sharon.app;

import sharon.serialization.*;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

import static sharon.serialization.Message.decode;

/**
 * Created by Chris on 9/27/2017.
 */
public class node implements Runnable{
    private String searchString;


    public static byte [] intToByteArray(int id)
    {
        String intToID = "";
        byte [] stringToID;

        intToID = Integer.toString(id);
        while(intToID.length() < 15)
        {
            intToID = '0' + intToID;
        }
        stringToID = intToID.getBytes();
        for(int i = 0; i < stringToID.length;i++)
        {
            stringToID[i] -= 48;
        }
        return stringToID;
    }

    public static void main(String [] args) throws IOException, BadAttributeValueException {
        if ((args.length < 3) ) { // Test for correct # of args
            throw new IllegalArgumentException("Parameter(s): <Address/Name> <Port> <Directory>");
        }
        String neighborName = args[0];
        int neighborPort = Integer.parseInt(args[1]);
        byte [] initMsg = "INIT SharOn/1.0\n\n".getBytes();
        int id = 0;
        int ttl = 100;
        byte[] sourceAddress = {0,0,0,0,0};
        byte[] destinationAddress = {0,0,0,0,0};

        String response;

        System.out.println("NeighborName: " + neighborName);
        System.out.println("NeighborNode: " + neighborPort);
        Socket clientSocket = new Socket(neighborName, neighborPort);
        System.out.println("Connected to server...sending echo string");

        OutputStream out = clientSocket.getOutputStream();
        MessageOutput outData = new MessageOutput(out);
        InputStream in = clientSocket.getInputStream();
        MessageInput data = new MessageInput(in);

        out.write(initMsg);

        response = data.getNodeResponse();


        if(response.equals("OK SharOn\n\n")) {
            System.out.println("Handshake Established");
            Listener newListener = new Listener(data,outData);
            newListener.start();
            while(true)
            {
                System.out.println("Enter a search");
                Scanner reader = new Scanner(System.in);  // Reading from System.in
                String search = reader.nextLine();
                System.out.println("Searching for: " + search);

                Search srch = new Search(intToByteArray(id),ttl, RoutingService.BREADTHFIRSTBROADCAST,
                        sourceAddress,destinationAddress,search);
                id++;
                Sender newSender = new Sender(srch,outData);
                newSender.start();

            }
        }
        else {
            System.out.println("HandShake Rejected\n" + response);
        }

    }



    @Override
    public void run() {

    }

    static class Sender implements Runnable {
        private Thread t;
        private Message msg;
        private MessageOutput outData;

        Sender(Message msg, MessageOutput out) {
            this.msg = msg;
            outData = out;
        }

        public void run() {
            try {
                synchronized (outData) {
                    msg.encode(outData);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void start() {
            if (t == null) {
                t = new Thread(this);
                t.start();
            }

        }
    }

    static class Listener implements Runnable {
        private Thread t;
        private Message msg;
        private MessageInput inData;
        private MessageOutput outData;


        Listener(MessageInput in, MessageOutput out) {
            inData = in;
            outData = out;
        }

        public void run() {
            try {
                synchronized (inData) {
                    while (true) {
                        msg = decode(inData);
                        if (msg instanceof Search) {

                        }
                        if (msg instanceof Response) {
                            System.out.println(msg.toString());
                        }
                    }
                }
            } catch (BadAttributeValueException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void start() {
            if (t == null) {
                t = new Thread(this);
                t.start();
            }

        }
    }

}
