/************************************************
 *
 * Author: Chris Simmons, Mitchell Shannon
 * Assignment: Program0Test
 * Class: CSI 4321 Data Communications
 *
 ************************************************/

package sharon.serialization;

import java.io.DataInputStream;
import java.io.IOException;

/**
 * Serialization input for messages
 */
public class MessageInput {
    long msgFileID;
    long msgFileSize;
    String msgFileName;

    /**
     *  Constructs that creates a new input source from an InputStream
     *
     * @param in is the byte input source
     *
     * @throws java.lang.NullPointerException
     *     if in is a null pointer
     */
    public MessageInput(java.io.InputStream in)
            throws NullPointerException, IOException {
        DataInputStream test = new DataInputStream(in);
        msgFileID = test.readInt();
        msgFileSize = test.readInt();
        char tmp;
        msgFileName = "";
        while ( (tmp = ((char) test.readByte()))!= '\n')
        {
            msgFileName += tmp;
        }
    }

    public MessageInput()
    {

    }

    /**
     * @return the msgFileName
     */
    public String getMsgFileName() {
        return msgFileName;
    }

    /**
     * @param msgFileName
     */
    public void setMsgFileName(String msgFileName) {
        this.msgFileName = msgFileName;
    }

    public long getMsgFileSize() {
        return msgFileSize;
    }

    public void setMsgFileSize(long msgFileSize) {
        this.msgFileSize = msgFileSize;
    }


    public long getMsgFileID() {
        return msgFileID;
    }

    public void setMsgFileID(long msgFileID) {
        this.msgFileID = msgFileID;
    }
}
